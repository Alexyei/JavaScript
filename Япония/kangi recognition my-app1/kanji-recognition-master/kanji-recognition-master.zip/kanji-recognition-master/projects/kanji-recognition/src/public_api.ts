/*
 * Public API Surface of kanji-recognition
 */

export * from './lib/kanji-recognition.service';
export * from './lib/kanji-recognition.component';
export * from './lib/kanji-recognition.module';
